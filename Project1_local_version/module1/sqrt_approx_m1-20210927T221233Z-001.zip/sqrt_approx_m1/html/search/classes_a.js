var searchData=
[
  ['osc_5ftype_0',['OSC_Type',['../struct_o_s_c___type.html',1,'']]]
];
